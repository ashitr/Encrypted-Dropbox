
    <?php
    $key = 4931b38bf036c31e9c666e246a5081e9;

    $flag = 'cs628a{' . $key . '}';

    ?>
    